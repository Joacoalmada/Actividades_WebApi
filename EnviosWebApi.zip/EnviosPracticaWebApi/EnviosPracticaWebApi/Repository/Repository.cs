﻿using EnviosWebApi.Models;

namespace EnviosPracticaWebApi.Repository
{

    public class Repository : IEnviosRepository
    {
        private EnviosContext _context;

        public Repository(EnviosContext context) 
        { 
            _context = context;
        }
        public bool Create(TEnvio Envio)
        {
            _context.TEnvios.Add(Envio);
            return _context.SaveChanges() == 1;
        }

        public bool delete(int id)
        {
            var entity = _context.TEnvios.Find(id);
            if (entity != null) 
            {
                entity.Estado = "Cancelado";
                _context.TEnvios.Update(entity);
                return _context.SaveChanges() > 0;

            }
            return false;
        }

        public List<TEnvio> GetAllByEstado(string estado)
        {
            return _context.TEnvios.Where(x => x.Estado == estado).ToList();
        }

        public List<TEnvio> GetAllByYear(DateTime anio1, DateTime anio2)
        {
            return _context.TEnvios.Where(p => p.FechaEnvio >= anio1 && anio2 <= p.FechaEnvio).ToList();
        }
    }
}

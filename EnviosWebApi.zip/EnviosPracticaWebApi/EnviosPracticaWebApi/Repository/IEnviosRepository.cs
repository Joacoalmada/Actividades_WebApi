﻿using EnviosWebApi.Models;

namespace EnviosPracticaWebApi.Repository
{
    public interface IEnviosRepository
    {
        List<TEnvio> GetAllByYear(DateTime anio1 , DateTime anio2 );

        List<TEnvio> GetAllByEstado(string estado);

        bool Create(TEnvio Envio);

        bool delete(int id);    
    }
}

﻿using EnviosPracticaWebApi.Repository;
using EnviosWebApi.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EnviosPracticaWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnvioController : ControllerBase
    {
        private IEnviosRepository _Repository;

        public EnvioController(IEnviosRepository repository)
        {
            _Repository = repository;
        }

        // GET: api/<EnvioController>
        [HttpGet("por - años")]
        public IActionResult GetAllByYears([FromQuery] DateTime anio1 , [FromQuery] DateTime anio2) 
        {
            try 
            {
                return Ok(_Repository.GetAllByYear(anio1, anio2));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error");
            }
        }

        // GET api/<EnvioController>/5
        [HttpGet("por - Estado")]
        public IActionResult GetAllByEstado(string estado) 
        {
            try
            {
                return Ok(_Repository.GetAllByEstado(estado));
            }
            catch (Exception ex) 
            {
                return StatusCode(500, "Error");
            }
        }

        // POST api/<EnvioController>
        [HttpPost]
        public IActionResult Create([FromBody] TEnvio envio)
        {
            try
            {
                if (IsValid(envio))
                {
                    return Ok(_Repository.Create(envio));
                }
                else 
                {
                    return BadRequest("Ingrese todos los datos correctamente");
                }
            }
            catch (Exception ex) 
            {
                return StatusCode(500, "Error"+ex);
 
            }
        }

        private bool IsValid(TEnvio envio)
        {
            return !string.IsNullOrEmpty(envio.Estado) && !string.IsNullOrEmpty(envio.Direccion) && !string.IsNullOrEmpty(envio.DniCliente) && envio.IdEmpresa > 0;
        }



        // DELETE api/<EnvioController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id) 
        {
            try 
            {
                return Ok(_Repository.delete(id));
            }
            catch (Exception ex) 
            {
                return StatusCode(500, "Error");
            }
        }
    }
}

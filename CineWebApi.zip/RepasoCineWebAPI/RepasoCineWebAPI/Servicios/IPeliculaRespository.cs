﻿using CineWebAPI.Models;
using Microsoft.AspNetCore.Components.Web;

namespace RepasoCineWebAPI.Servicios
{
    public interface IPeliculaRespository
    {
        List<Pelicula> GetAll();

        bool Update(int id);

        bool Create(Pelicula pelicula);

        bool Delete(int id,string motivo);

        List<Pelicula> GetAllYear(int anio1, int anio2);


    }
}

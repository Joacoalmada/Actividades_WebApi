﻿using CineWebAPI.Models;

namespace RepasoCineWebAPI.Servicios
{
    public class PeliculaRepository : IPeliculaRespository
    {
        private CineContext _context;

        public PeliculaRepository(CineContext context) 
        {
            _context = context;
        }
        public bool Create(Pelicula pelicula)
        {
           _context.Peliculas.Add(pelicula);
            return _context.SaveChanges() == 1 ;
        }

        public bool Delete(int id,string motivo)
        {
           var entity = _context.Peliculas.Find(id);
            if(entity == null) 
            {
                return false;
            }
            _context.Peliculas.Remove(entity);
             _context.SaveChanges();
            return true;
        }

        public List<Pelicula> GetAll()
        {
            return _context.Peliculas.Where(x => x.Estreno).ToList();
        }

        public List<Pelicula> GetAllYear(int anio1, int anio2)
        {
            return _context.Peliculas.Where(p => p.Anio >= anio1 && p.Anio <= anio2).ToList();
        }

        public bool Update(int id)
        {
            var entity = _context.Peliculas.Find(id);
            if (entity != null)
            {
                entity.Estreno = false;
                return _context.SaveChanges() > 0;
            }
            return false;
        }
    }
}

﻿using CineWebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using RepasoCineWebAPI.Servicios;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RepasoCineWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PeliculaController : ControllerBase
    {
        private IPeliculaRespository _Repository;
        
        public PeliculaController(IPeliculaRespository respository) 
        {
            _Repository = respository;
        }

        // GET: api/<PeliculaController>
        [HttpGet]
        public IActionResult Get()
        {

            try
            {
                
                return Ok(_Repository.GetAll());
            }
            catch (Exception ex) 
            {
                return StatusCode(500, "Error fatal payasito aimar");
            }
        }

        [HttpGet("By-Rango")]

        public IActionResult GetByYear([FromQuery]int anio1 ,[FromQuery] int anio2) 
        {
            try
            {
                return Ok(_Repository.GetAllYear(anio1, anio2));
            }
            catch (Exception ex) 
            {
                return StatusCode(500, "Error fatal payasito aimar");
            }
        
        }

        // POST api/<PeliculaController>
        [HttpPost]
        public IActionResult Post([FromBody] Pelicula pelicula) 
        {
            try
            {
                if (IsValid(pelicula)) 
                {
                    return Ok(_Repository.Create(pelicula));
                }
                else
                {
                    return BadRequest("Completa con los campos pedidos");
                }
            }
            catch (Exception ex) 
            {
                return StatusCode(500, "Error fatal payasito aimar");
            }
        }

        private bool IsValid(Pelicula pelicula)
        {
            return !string.IsNullOrEmpty(pelicula.Titulo) && !string.IsNullOrEmpty(pelicula.Director) && pelicula.Anio > 0 && pelicula.IdGenero > 0;
        }

        // PUT api/<PeliculaController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id)
        {
            try
            {
                if (!_Repository.Update(id)) 
                {
                    return NotFound("ingrese los datos correctamente");
                }
                else 
                {
                    return Ok(_Repository.Update(id));
                }
            }
            catch (Exception ex) 
            {
                return StatusCode(500, "Error fatal payasito aimar");
            }
        }

        // DELETE api/<PeliculaController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id, [FromBody] string motivo) 
        {
            try
            {
                if (!_Repository.Delete(id,motivo))
                {
                    return NotFound("No se encontro el id");
                }
                else 
                {
                    return Ok(_Repository.Delete(id,motivo));
                }
            }
            catch (Exception)
            {

                return StatusCode(500, "Error fatal payasito aimar");
            }
        }
    }
}

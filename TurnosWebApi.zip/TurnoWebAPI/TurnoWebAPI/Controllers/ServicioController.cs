﻿using Microsoft.AspNetCore.Mvc;
using TurnoApi.Models;
using TurnoWebAPI.Repositorios;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TurnoWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServicioController : ControllerBase
    {
        private readonly IRepositorioServicio _repositorioServicio;

        public ServicioController(IRepositorioServicio repositorioServicio)
        {
            _repositorioServicio = repositorioServicio;
        }


        // GET api/<ServicioController>
        [HttpGet]
        public async Task<IActionResult> GetServicios()
        {
            var servicios = await _repositorioServicio.ObtenerTodos();
            return Ok(servicios);
        }

        // POST api/<ServicioController>/registrar
        [HttpPost("registrar")]
        public async Task<IActionResult> Registrar([FromBody]TServicio servicio)
        {
            try
            {
                await _repositorioServicio.Registrar(servicio);
                return Ok("Se a registrado el servicio");
            }
            catch (Exception ex) 
            {
                return StatusCode(500, "Error "+ex);
            }
        }

        // PUT api/<ServicioController>/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Editar(int id, TServicio servicio)
        {
            try
            {
                if (id != servicio.Id)
                {
                    return BadRequest();
                }
                await _repositorioServicio.Editar(servicio);
                return Ok("Se puedo editar el servicio");
            }
            catch (Exception) 
            {
                return StatusCode(500, "No se a podido editar" );
            }
        }
        [HttpDelete]
        public IActionResult Delete([FromQuery] int id)
        {
            try
            {
                return Ok(_repositorioServicio.Delete(id));
            }
            catch (Exception) 
            {
                return StatusCode(500, "No se puedo borrar ");
            }
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using System;
using TurnoApi.Models;
using TurnoWebAPI.Models;

namespace TurnoWebAPI.Repositorios
{
    public class RepositorioServicio : IRepositorioServicio
    {
        private readonly TurnosDbContext _context;

        public RepositorioServicio(TurnosDbContext context) 
        { 
            _context = context;
        }

        public async Task Delete(int id)
        {
            var servicio = await _context.TServicio.FindAsync(id);
            if (servicio != null)
            {
                _context.TServicio.Remove(servicio);
                await _context.SaveChangesAsync();
            }
        }

        public async Task Editar(TServicio servicio)
        {
            _context.TServicio.Update(servicio);
             await _context.SaveChangesAsync();
        }

        public async Task<TServicio> ObtenerPorId(int id)
        {
            return await _context.TServicio.FindAsync(id);
        }

        public async Task<IEnumerable<TServicio>> ObtenerTodos()
        {
            return await _context.TServicio.ToListAsync();
        }

        public async Task Registrar(TServicio servicio)
        {
            var entity = await _context.TServicio.AddAsync(servicio);
            await _context.SaveChangesAsync();
        }

       
    }
}

﻿using TurnoApi.Models;

namespace TurnoWebAPI.Repositorios
{
    public interface IRepositorioServicio
    {
        Task<IEnumerable<TServicio>> ObtenerTodos();
        Task<TServicio> ObtenerPorId(int id);
        Task Registrar(TServicio servicio);
        Task Editar(TServicio servicio);

        Task Delete(int id);    
        
    }
}

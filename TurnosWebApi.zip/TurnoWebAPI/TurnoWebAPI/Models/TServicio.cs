﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TurnoApi.Models;

public partial class TServicio
{
    
    public int Id { get; set; }
    
    public string Nombre { get; set; }

    public int Costo { get; set; }

    public string EnPromocion { get; set; } 

    public ICollection<TDetallesTurno> DetallesTurno = new List<TDetallesTurno>();
}

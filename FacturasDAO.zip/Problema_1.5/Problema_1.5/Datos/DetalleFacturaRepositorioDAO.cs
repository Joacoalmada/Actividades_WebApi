﻿using Problema_1._5.Datos.Utilidades;
using Problema_1._5.Dominio;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_1._5.Datos
{
    public class DetalleFacturaRepositorioDAO : IDetalleFacturaRepositorio
    {
        public bool add(DetalleFactura detalleFactura)
        {
           var parametro = new List<ParametrosSQL>
           {
                new ParametrosSQL("@id_DetalleFactura",detalleFactura.id_DetalleFactura),
                new ParametrosSQL("@cantidad",detalleFactura.Cantidad),
                new ParametrosSQL("@articuloId",detalleFactura.Articulo.Id_Articulo),
           };
            int filasAfectadas = DataHelper.GetInstance().EjecutarSPDML("SP_CREAR_FACTURA", parametro);
            return filasAfectadas > 0; 
        }

        public List<DetalleFactura> GetAll()
        {
            var DetFactura = new List<DetalleFactura>();
            DataTable table = DataHelper.GetInstance().EjecutarPA("SP_MOSTRAR_DETALLES");
            if (table != null)
            {
                foreach (DataRow row in table.Rows)
                {
                    DetalleFactura D = new DetalleFactura
                    {
                        id_DetalleFactura = Convert.ToInt32(row["id_DetalleFactura"]),
                        Cantidad = Convert.ToInt32(row["cantidad"]),
                        Articulo = new Articulo 
                        { 
                            Id_Articulo =Convert.ToInt32( row["id_Articulo"]),
                            Nombre_Art = Convert.ToString(row["nombre"]),
                            Precio = Convert.ToInt32(row["precioUnitario"])
                        }
                       
                    };
                    DetFactura.Add(D);
                }
            }
            return DetFactura;
        }
    }
    
}
